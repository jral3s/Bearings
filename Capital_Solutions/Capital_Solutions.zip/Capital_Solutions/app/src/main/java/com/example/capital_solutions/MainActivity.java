package com.example.capital_solutions;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import java.util.Calendar;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MainActivity extends AppCompatActivity {

    public static final String MyPREFERENCES = "MyPrefs" ;
    /*public static final String IncomeKey = "incomeKey";
    public static final String HousingKey = "housingKey";
    public static final String TransportationKey = "transportationKey";
    public static final String SavingsKey = "savingsKey";
    public static final String BudgetKey = "budgetKey";
    public static final String FoodKey = "foodKey";
    public static final String ClothesKey = "clothesKey";
    public static final String OtherKey = "otherKey";*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);

        SharedPreferences sharedPref = this.getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        //DatabaseHelper db = new DatabaseHelper(this);

      /*  editor.putString(IncomeKey, "0");
        editor.putString(HousingKey, "0");
        editor.putString(TransportationKey, "0");
        editor.putString(SavingsKey, "0");
        editor.putString(BudgetKey, "0");
        editor.putString(FoodKey, "0");
        editor.putString(ClothesKey, "0");
        editor.putString(OtherKey, "0"); */
    }

}
